--- @module 'SmithyGUI'
--- @version 1.0.0
--- ImGui-based GUI for Smithy script

---@diagnostic disable: undefined-global, unused-local, unused-function, trailing-space

local API = require("api")

local SmithyGUI = {}

SmithyGUI.open = true
SmithyGUI.started = false
SmithyGUI.paused = false
SmithyGUI.stopped = false
SmithyGUI.cancelled = false
SmithyGUI.selectTaskTab = true
SmithyGUI.selectInfoTab = false

SmithyGUI.tasks = {}
SmithyGUI.currentTaskIndex = 1

SmithyGUI.config = {
    autoRun = false,
}

local SCRIPT_DIR = ""
local CONFIG_DIR = ""
local CONFIG_PATH = ""

local THEME = {
    dark = { 0.12, 0.08, 0.04 },
    medium = { 0.25, 0.15, 0.08 },
    light = { 0.40, 0.25, 0.12 },
    bright = { 0.60, 0.40, 0.20 },
    glow = { 0.85, 0.65, 0.30 },
    accent = { 0.90, 0.75, 0.40 },
}

SmithyGUI.showAddTaskDialog = false
SmithyGUI.showEditTaskDialog = false
SmithyGUI.selectedTaskIndex = nil
SmithyGUI.editingTaskIndex = nil

SmithyGUI.callbacks = {
    addTask = nil,
    editTask = nil,
    removeTask = nil,
    moveTaskUp = nil,
    moveTaskDown = nil,
    clearAllTasks = nil,
}

function SmithyGUI.setCallbacks(callbacks)
    SmithyGUI.callbacks = callbacks or {}
end

function SmithyGUI.setItems(items)
    SmithyGUI.ITEMS = items
end

local function sectionHeader(text)
    ImGui.PushStyleColor(ImGuiCol.Text, THEME.glow[1], THEME.glow[2], THEME.glow[3], 1.0)
    ImGui.TextWrapped(text)
    ImGui.PopStyleColor(1)
end

local function flavorText(text)
    ImGui.PushStyleColor(ImGuiCol.Text, 0.70, 0.55, 0.40, 1.0)
    ImGui.TextWrapped(text)
    ImGui.PopStyleColor(1)
end

function SmithyGUI.setScriptDirectory(dir)
    SCRIPT_DIR = dir
    CONFIG_DIR = SCRIPT_DIR .. "configs/"
    local playerName = API.GetLocalPlayerName() or "default"
    CONFIG_PATH = CONFIG_DIR .. "smithy." .. playerName .. ".config.json"
end

function SmithyGUI.getConfig()
    return SmithyGUI.config
end

function SmithyGUI.getTasks()
    return SmithyGUI.tasks
end

function SmithyGUI.setTasks(tasks)
    SmithyGUI.tasks = tasks or {}
end

function SmithyGUI.getCurrentTaskIndex()
    return SmithyGUI.currentTaskIndex
end

function SmithyGUI.setCurrentTaskIndex(index)
    SmithyGUI.currentTaskIndex = index or 1
end

function SmithyGUI.reset()
    SmithyGUI.open = true
    SmithyGUI.started = false
    SmithyGUI.paused = false
    SmithyGUI.stopped = false
    SmithyGUI.cancelled = false
    SmithyGUI.selectTaskTab = true
    SmithyGUI.selectInfoTab = false
    SmithyGUI.showAddTaskDialog = false
    SmithyGUI.showEditTaskDialog = false
end

function SmithyGUI.isCancelled()
    return SmithyGUI.cancelled
end

function SmithyGUI.isPaused()
    return SmithyGUI.paused
end

function SmithyGUI.isStopped()
    return SmithyGUI.stopped
end

local addTaskState = {
    selectedMetal = 0,
    selectedItem = 0,
    selectedLevel = 0,
    amount = 1,
    fromBase = false,
}

local editTaskState = {
    amount = 1,
}

local ITEM_TYPES = {}
local ITEM_LEVELS = {}

local function drawAddTaskDialog()
    if not SmithyGUI.showAddTaskDialog then return end
    
    local shouldClose = false
    
    if not addTaskState.selectedMetal then
        addTaskState.selectedMetal = 0
        addTaskState.selectedItem = 0
        addTaskState.selectedLevel = 0
        addTaskState.amount = 1
        addTaskState.fromBase = false
    end
    
    -- Get ITEMS data
    local items = SmithyGUI.ITEMS or {}
    
    -- Build metal list from ITEMS - filter for smithing metals only
    local metals = {}
    for metal, metalItems in pairs(items) do
        -- Check if this is a smithing metal (has items like BAR, PLATEBODY, etc.)
        local isSmithingMetal = false
        for itemName, _ in pairs(metalItems) do
            if itemName == "BAR" or itemName == "PLATEBODY" or itemName == "FULL_HELM" or 
               itemName == "PLATELEGS" or itemName == "SET" or itemName == "ARROWHEADS" then
                isSmithingMetal = true
                break
            end
        end
        if isSmithingMetal then
            table.insert(metals, metal)
        end
    end
    table.sort(metals)
    
    -- Build metalList for Combo (table)
    local metalList = {}
    for i, metal in ipairs(metals) do
        metalList[i] = metal
    end
    
    -- Ensure selectedMetal is valid
    if addTaskState.selectedMetal >= #metals then
        addTaskState.selectedMetal = 0
    end
    
    -- Get selected metal and build item list
    local selectedMetal = metals[addTaskState.selectedMetal + 1]
    local itemsForMetal = {}
    if selectedMetal and items[selectedMetal] then
        for item, _ in pairs(items[selectedMetal]) do
            table.insert(itemsForMetal, item)
        end
        table.sort(itemsForMetal)
    end
    
    -- Build itemList for Combo (table)
    local itemList = {}
    for i, item in ipairs(itemsForMetal) do
        itemList[i] = item
    end
    
    -- Ensure selectedItem is valid
    if addTaskState.selectedItem >= #itemsForMetal then
        addTaskState.selectedItem = 0
    end
    
    -- Get selected item and build level list
    local selectedItem = itemsForMetal[addTaskState.selectedItem + 1]
    local levels = {}
    if selectedMetal and selectedItem and items[selectedMetal] and items[selectedMetal][selectedItem] then
        for level, _ in pairs(items[selectedMetal][selectedItem]) do
            table.insert(levels, level)
        end
        table.sort(levels, function(a, b)
            if a == "BURIAL" then return false end
            if b == "BURIAL" then return true end
            return tonumber(a) < tonumber(b)
        end)
    end
    
    -- Build levelList for Combo (table)
    local levelList = {}
    for i, level in ipairs(levels) do
        levelList[i] = tostring(level)
    end
    
    -- Ensure selectedLevel is valid
    if addTaskState.selectedLevel >= #levels then
        addTaskState.selectedLevel = 0
    end
    
    ImGui.SetNextWindowSize(400, 400, ImGuiCond.FirstUseEver)
    local shouldDraw, shouldCloseWindow = ImGui.Begin("Add Task###addtask", true, ImGuiWindowFlags.AlwaysAutoResize)
    
    if shouldDraw then
        ImGui.Text("Add a new smithing task:")
        ImGui.Separator()
        ImGui.Spacing()
        
        ImGui.Text("Metal Type:")
        local metalChanged, newMetal = ImGui.Combo("##metal", addTaskState.selectedMetal, metalList, #metals)
        if metalChanged then
            addTaskState.selectedMetal = newMetal
            addTaskState.selectedItem = 0
            addTaskState.selectedLevel = 0
        end
        
        ImGui.Spacing()
        
        ImGui.Text("Item Type:")
        local itemChanged, newItem = ImGui.Combo("##item", addTaskState.selectedItem, itemList, #itemsForMetal)
        if itemChanged then
            addTaskState.selectedItem = newItem
            addTaskState.selectedLevel = 0
        end
        
        ImGui.Spacing()
        
        ImGui.Text("Item Level:")
        local levelChanged, newLevel = ImGui.Combo("##level", addTaskState.selectedLevel, levelList, #levels)
        if levelChanged then
            addTaskState.selectedLevel = newLevel
        end
        
        ImGui.Spacing()
        
        ImGui.Text("Amount:")
        local amountChanged, newAmount = ImGui.InputInt("##amount", addTaskState.amount, 1, 10)
        if amountChanged then
            addTaskState.amount = math.max(1, newAmount)
        end
        
        ImGui.Spacing()
        
        local fromBaseChanged, newFromBase = ImGui.Checkbox("From Base (create all levels from 0)", addTaskState.fromBase)
        if fromBaseChanged then
            addTaskState.fromBase = newFromBase
        end
        if addTaskState.fromBase then
            local targetLevel = levels[addTaskState.selectedLevel + 1] or "selected"
            ImGui.Text("Will create tasks for levels 0 through " .. tostring(targetLevel))
        end
        
        ImGui.Spacing()
        ImGui.Separator()
        ImGui.Spacing()
        
        if ImGui.Button("Add", 120, 0) then
            if #metals > 0 and #itemsForMetal > 0 and #levels > 0 then
                local selectedLevel = levels[addTaskState.selectedLevel + 1]
                -- Ensure itemLevel is a string for consistency with ITEMS table keys
                local task = {
                    metalType = metals[addTaskState.selectedMetal + 1],
                    itemType = itemsForMetal[addTaskState.selectedItem + 1],
                    itemLevel = tostring(selectedLevel),
                    amount = addTaskState.amount,
                    fromBase = addTaskState.fromBase,
                }
                
                if SmithyGUI.callbacks.addTask then
                    SmithyGUI.callbacks.addTask(task)
                end
                
                addTaskState.selectedMetal = 0
                addTaskState.selectedItem = 0
                addTaskState.selectedLevel = 0
                addTaskState.amount = 1
                addTaskState.fromBase = false
                shouldClose = true
            end
        end
        
        ImGui.SameLine()
        
        if ImGui.Button("Cancel", 120, 0) then
            shouldClose = true
        end
    end
    
    ImGui.End()
    
    if not shouldDraw or shouldClose then
        SmithyGUI.showAddTaskDialog = false
    end
end

local function drawEditTaskDialog()
    if not SmithyGUI.showEditTaskDialog then return end
    if not SmithyGUI.editingTaskIndex then return end
    
    local task = SmithyGUI.tasks[SmithyGUI.editingTaskIndex]
    if not task then
        SmithyGUI.showEditTaskDialog = false
        return
    end
    
    local shouldClose = false
    
    if editTaskState.amount == 1 then
        editTaskState.amount = task.amount or 1
    end
    
    ImGui.SetNextWindowSize(400, 300, ImGuiCond.FirstUseEver)
    local shouldDraw, shouldCloseWindow = ImGui.Begin("Edit Task###edittask", true, ImGuiWindowFlags.AlwaysAutoResize)
    
    if shouldDraw then
        ImGui.Text("Edit task:")
        ImGui.Separator()
        ImGui.Spacing()
        
        ImGui.Text("Metal: " .. tostring(task.metalType))
        ImGui.Text("Item: " .. tostring(task.itemType))
        ImGui.Text("Level: " .. tostring(task.itemLevel))
        
        ImGui.Spacing()
        ImGui.Separator()
        ImGui.Spacing()
        
        ImGui.Text("Amount:")
        local amountChanged, newAmount = ImGui.InputInt("##editamount", editTaskState.amount, 1, 10)
        if amountChanged then
            editTaskState.amount = math.max(1, newAmount)
        end
        
        ImGui.Spacing()
        ImGui.Separator()
        ImGui.Spacing()
        
        if ImGui.Button("Save", 120, 0) then
            local updatedTask = {
                metalType = task.metalType,
                itemType = task.itemType,
                itemLevel = tostring(task.itemLevel),
                amount = editTaskState.amount,
            }
            
            if SmithyGUI.callbacks.editTask then
                SmithyGUI.callbacks.editTask(SmithyGUI.editingTaskIndex, updatedTask)
            end
            
            editTaskState.amount = 1
            shouldClose = true
        end
        
        ImGui.SameLine()
        
        if ImGui.Button("Cancel", 120, 0) then
            shouldClose = true
        end
    end
    
    ImGui.End()
    
    if not shouldDraw or shouldClose then
        editTaskState.amount = 1
        SmithyGUI.showEditTaskDialog = false
        SmithyGUI.editingTaskIndex = nil
    end
end

function SmithyGUI.draw(data)
    data = data or {}
    
    ImGui.SetNextWindowSize(480, 0, ImGuiCond.Always)
    ImGui.SetNextWindowPos(100, 100, ImGuiCond.FirstUseEver)
    
    -- Apply bronze/gold theme
    ImGui.PushStyleColor(ImGuiCol.WindowBg, THEME.dark[1], THEME.dark[2], THEME.dark[3], 0.97)
    ImGui.PushStyleColor(ImGuiCol.TitleBg, THEME.medium[1] * 0.6, THEME.medium[2] * 0.6, THEME.medium[3] * 0.6, 1.0)
    ImGui.PushStyleColor(ImGuiCol.TitleBgActive, THEME.medium[1], THEME.medium[2], THEME.medium[3], 1.0)
    ImGui.PushStyleColor(ImGuiCol.Separator, THEME.light[1], THEME.light[2], THEME.light[3], 0.4)
    ImGui.PushStyleColor(ImGuiCol.Tab, THEME.medium[1], THEME.medium[2], THEME.medium[3], 1.0)
    ImGui.PushStyleColor(ImGuiCol.TabHovered, THEME.light[1], THEME.light[2], THEME.light[3], 1.0)
    ImGui.PushStyleColor(ImGuiCol.TabActive, THEME.bright[1], THEME.bright[2], THEME.bright[3], 1.0)
    ImGui.PushStyleColor(ImGuiCol.Button, THEME.medium[1], THEME.medium[2], THEME.medium[3], 0.8)
    ImGui.PushStyleColor(ImGuiCol.ButtonHovered, THEME.light[1], THEME.light[2], THEME.light[3], 1.0)
    ImGui.PushStyleColor(ImGuiCol.ButtonActive, THEME.bright[1], THEME.bright[2], THEME.bright[3], 1.0)
    ImGui.PushStyleColor(ImGuiCol.FrameBg, THEME.dark[1] * 1.5, THEME.dark[2] * 1.5, THEME.dark[3] * 1.5, 0.9)
    ImGui.PushStyleColor(ImGuiCol.FrameBgHovered, THEME.light[1] * 0.5, THEME.light[2] * 0.5, THEME.light[3] * 0.5, 0.8)
    ImGui.PushStyleColor(ImGuiCol.CheckMark, THEME.accent[1], THEME.accent[2], THEME.accent[3], 1.0)
    ImGui.PushStyleColor(ImGuiCol.SliderGrab, THEME.bright[1], THEME.bright[2], THEME.bright[3], 1.0)
    
    ImGui.PushStyleVar(ImGuiStyleVar.WindowRounding, 8.0)
    ImGui.PushStyleVar(ImGuiStyleVar.FrameRounding, 4.0)
    ImGui.PushStyleVar(ImGuiStyleVar.GrabRounding, 4.0)
    ImGui.PushStyleVar(ImGuiStyleVar.PopupRounding, 6.0)
    ImGui.PushStyleVar(ImGuiStyleVar.FramePadding, 4, 4)
    
    local windowOpen, windowFlags = ImGui.Begin("Smithy", SmithyGUI.open, ImGuiWindowFlags.AlwaysAutoResize)
    SmithyGUI.open = windowOpen
    
    local success, err = pcall(function()
    if windowOpen then
        if ImGui.BeginTabBar("smithy_tabs", 0) then
        
            if ImGui.BeginTabItem("Tasks") then
                sectionHeader("Task Queue")
                
                if ImGui.Button("Add Task", 100, 0) then
                    SmithyGUI.showAddTaskDialog = true
                end
                
                ImGui.SameLine()
                if ImGui.Button("Clear All", 100, 0) then
                    if SmithyGUI.callbacks.clearAllTasks then
                        SmithyGUI.callbacks.clearAllTasks()
                    end
                    SmithyGUI.selectedTaskIndex = nil
                end
                
                ImGui.Spacing()
                ImGui.Separator()
                ImGui.Spacing()
                
                if SmithyGUI.tasks and #SmithyGUI.tasks > 0 then
                    ImGui.PushID("task_table")
                    if ImGui.BeginTable("task_table", 5) then
                        ImGui.TableSetupColumn("Metal", ImGuiTableColumnFlags.WidthFixed, 80)
                        ImGui.TableSetupColumn("Item", ImGuiTableColumnFlags.WidthFixed, 100)
                        ImGui.TableSetupColumn("Level", ImGuiTableColumnFlags.WidthFixed, 50)
                        ImGui.TableSetupColumn("Qty", ImGuiTableColumnFlags.WidthFixed, 40)
                        ImGui.TableSetupColumn("Actions", ImGuiTableColumnFlags.WidthFixed, 90)
                        ImGui.TableHeadersRow()
                        
                        for i, task in ipairs(SmithyGUI.tasks or {}) do
                            ImGui.TableNextRow()
                            
                            -- Highlight selected row
                            if i == SmithyGUI.selectedTaskIndex then
                                ImGui.TableSetBgColor(ImGuiTableBgTarget.RowBg0, 0.3, 0.6, 0.9, 0.3)
                            end
                            
                            ImGui.TableNextColumn()
                            ImGui.Text(tostring(task.metalType or "?"))
                            
                            ImGui.TableNextColumn()
                            ImGui.Text(tostring(task.itemType or "?"))
                            
                            ImGui.TableNextColumn()
                            ImGui.Text(tostring(task.itemLevel or "?"))
                            
                            ImGui.TableNextColumn()
                            ImGui.Text(tostring(task.amount or 1))
                            
                            ImGui.TableNextColumn()
                            ImGui.PushID(i)
                            ImGui.PushStyleVar(ImGuiStyleVar.Alpha, i > 1 and 1.0 or 0.3)
                            if ImGui.Button("\u{f062}##up", 24, 0) then
                                if i > 1 and SmithyGUI.callbacks.moveTaskUp then
                                    SmithyGUI.callbacks.moveTaskUp(i)
                                    SmithyGUI.selectedTaskIndex = i - 1
                                end
                            end
                            ImGui.PopStyleVar()
                            ImGui.SameLine()
                            ImGui.PushStyleVar(ImGuiStyleVar.Alpha, i < #SmithyGUI.tasks and 1.0 or 0.3)
                            if ImGui.Button("\u{f063}##dn", 24, 0) then
                                if i < #SmithyGUI.tasks and SmithyGUI.callbacks.moveTaskDown then
                                    SmithyGUI.callbacks.moveTaskDown(i)
                                    SmithyGUI.selectedTaskIndex = i + 1
                                end
                            end
                            ImGui.PopStyleVar()
                            ImGui.SameLine()
                            if ImGui.Button("\u{f1f8}##del", 24, 0) then
                                if SmithyGUI.callbacks.removeTask then
                                    SmithyGUI.callbacks.removeTask(i)
                                end
                            end
                            ImGui.PopID()
                        end
                        
                        ImGui.EndTable()
                    end
                    ImGui.PopID()
                else
                    flavorText("No tasks queued. Add one to get started.")
                end
                
                ImGui.EndTabItem()
            end
            
            if ImGui.BeginTabItem("Info") then
                sectionHeader("Runtime Info")
                
                -- Display current task details
                local currentTask = SmithyGUI.tasks[SmithyGUI.currentTaskIndex]
                if currentTask then
                    ImGui.Text("Current Task: " .. tostring(currentTask.metalType) .. " " .. tostring(currentTask.itemType))
                    ImGui.Text("Level: " .. tostring(currentTask.itemLevel) .. "  |  Amount: x" .. tostring(currentTask.amount))
                    ImGui.Text("Progress: Task " .. SmithyGUI.currentTaskIndex .. " of " .. #SmithyGUI.tasks)
                else
                    ImGui.Text("Current Task: None")
                    ImGui.Text("All tasks completed!")
                end
                
                ImGui.Spacing()
                ImGui.Separator()
                ImGui.Spacing()
                
                -- Task queue summary
                ImGui.Text("Task Queue Summary:")
                ImGui.Text("Total Tasks: " .. #SmithyGUI.tasks)
                ImGui.Text("Current Position: " .. SmithyGUI.currentTaskIndex)
                
                sectionHeader("Script Control")
                
                if ImGui.Button("Start", 100, 0) then
                    SmithyGUI.started = true
                    SmithyGUI.paused = false
                    SmithyGUI.stopped = false
                end
                ImGui.SameLine()
                if ImGui.Button("Pause", 100, 0) then
                    SmithyGUI.paused = not SmithyGUI.paused
                end
                ImGui.SameLine()
                if ImGui.Button("Stop", 100, 0) then
                    SmithyGUI.stopped = true
                end
                
                ImGui.EndTabItem()
            end
            
            ImGui.EndTabBar()
        end
        
        drawAddTaskDialog()
        drawEditTaskDialog()
    end
    end)
    
    if not success then
        print("GUI ERROR: " .. tostring(err))
    end
    
    ImGui.PopStyleVar(5)
    ImGui.PopStyleColor(14)
    ImGui.End()
    
    return SmithyGUI.open
end

return SmithyGUI
