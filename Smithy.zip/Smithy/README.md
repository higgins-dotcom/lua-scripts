<a name="readme-top"></a>
<div align="center">
  <a href="https://github.com/higgins-dotcom/lua-scripts">
    <img src="images/logo.png" alt="Logo">
  </a>
  <h3 align="center">Smithy<br>Artisans' Workshop AIO Smither/Smelter</h3>

  <img src="images/bar.png" alt="GUI">

  
</div>


<!-- TABLE OF CONTENTS -->
<details>
  <summary>Table of Contents</summary>
  <ol>
    <li>
      <a href="#quick-start">Quick start</a>
      <ul>
        <li><a href="#prerequisites">Prerequisites</a></li>
      </ul>
    </li>
    <li><a href="#roadmap">Roadmap</a></li>
  </ol>
</details>

## ⚡️ Quick start

Download [Smithy](https://github.com/higgins-dotcom/lua-scripts/raw/main/Smithy/Smithy.zip) and extract into the Lua_Scripts folder<br>
Open Smithy.lua and add your tasks to the TASKS section<br>
Update any other settings<br>
Start Script

## ⚙️ Prerequisites

Start in Artisans' Workshop

<img src="images/code1.png" width="70%">

## 📝 Roadmap

- [ ] None

<p align="right">(<a href="#readme-top">back to top</a>)</p>